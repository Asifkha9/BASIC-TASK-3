import React, { useState, useEffect } from 'react';
import axios from 'axios';
import LocationInput from './LocationInput';
import WeatherDisplay from './WeatherDisplay';

const Weather = () => {
  const [weatherData, setWeatherData] = useState(null);
  const [location, setLocation] = useState('');

  useEffect(() => {
    if (location) {
      const fetchWeatherData = async () => {
        try {
          const response = await axios.get(
            `https://api.openweathermap.org/data/2.5/forecast?q=${location}&appid=${process.env.REACT_APP_WEATHER_API_KEY}&units=metric`
          );
          setWeatherData(response.data);
        } catch (error) {
          console.error("Error fetching weather data:", error);
        }
      };
      fetchWeatherData();
    }
  }, [location]);

  useEffect(() => {
    navigator.geolocation.getCurrentPosition((position) => {
      const { latitude, longitude } = position.coords;
      setLocation(`${latitude},${longitude}`);
    });
  }, []);

  return (
    <div>
      <LocationInput setLocation={setLocation} />
      {weatherData && <WeatherDisplay data={weatherData} />}
    </div>
  );
};

export default Weather;