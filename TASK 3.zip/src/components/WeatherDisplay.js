import React from 'react';

const WeatherDisplay = ({ data }) => {
  return (
    <div>
      <h2>Weather Forecast for {data.city.name}</h2>
      <ul>
        {data.list.slice(0, 5).map((item, index) => (
          <li key={index}>
            <p>{new Date(item.dt * 1000).toLocaleDateString()}</p>
            <p>Temperature: {item.main.temp} °C</p>
            <p>Weather: {item.weather[0].description}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default WeatherDisplay;